Free Icon downloaded from https://www.iconfinder.com.

Author: Webalys
Homepage: https://www.iconfinder.com/webalys